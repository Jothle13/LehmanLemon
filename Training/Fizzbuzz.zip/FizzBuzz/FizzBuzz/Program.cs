﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 100;
            FizzBuzz(number);
        }
        /*
         * This program will recieve int X and print all numbers from 1-x 
         * (if x is 3 it would say:
         * 1
         * 2
         * 3)
         * 
         * Here's the catch: \
         * Numbers that are divisible by 3 will be replaced with Fizz
         * Numbers that are divisible by 5 will be replaced with Buzz
         * Numbers that are divisible by both will be replaced with FizzBuzz
         * 
         */
        static void FizzBuzz(int x)
        {
            Console.WriteLine(x);
        }
    }
}
