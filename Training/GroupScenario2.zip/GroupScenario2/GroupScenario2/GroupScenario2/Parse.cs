﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupScenario2
{
    public class Parse
    {
        /// <summary>
        /// This is your input. Save your equation into this instance of the class.
        /// </summary>
        /// <param name="equation"></param>
        public void ParseString(string equation)
        {

        }
        /// <summary>
        /// Print one line for each iteration (i.e. for y=x*2 at 4 iterations:
        /// 1: 2
        /// 2: 4
        /// 3: 6
        /// 4: 8
        /// </summary>
        /// <param name="iterations"></param>
        public void GetResults(int iterations)
        {

        }
    }
}
